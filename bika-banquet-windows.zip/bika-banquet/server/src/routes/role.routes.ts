import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createRole,
  createRoleSchema,
  deleteRole,
  getRoleById,
  getRoles,
  updateRole,
  updateRoleSchema,
} from '../controllers/role.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createRoleSchema), createRole);
router.get('/', getRoles);
router.get('/:id', getRoleById);
router.put('/:id', validate(updateRoleSchema), updateRole);
router.delete('/:id', deleteRole);

export default router;
