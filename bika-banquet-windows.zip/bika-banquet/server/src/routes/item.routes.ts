import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createItem,
  createItemSchema,
  deleteItem,
  getItemById,
  getItems,
  updateItem,
  updateItemSchema,
} from '../controllers/item.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createItemSchema), createItem);
router.get('/', getItems);
router.get('/:id', getItemById);
router.put('/:id', validate(updateItemSchema), updateItem);
router.delete('/:id', deleteItem);

export default router;
