import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createHall,
  createHallSchema,
  deleteHall,
  getHallById,
  getHalls,
  updateHall,
  updateHallSchema,
} from '../controllers/hall.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createHallSchema), createHall);
router.get('/', getHalls);
router.get('/:id', getHallById);
router.put('/:id', validate(updateHallSchema), updateHall);
router.delete('/:id', deleteHall);

export default router;
