import { Router } from 'express';
import {
  createBooking,
  getBookings,
  getBookingById,
  updateBooking,
  cancelBooking,
  addPayment,
  createBookingSchema,
} from '../controllers/booking.controller';
import { authenticate, requirePermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';

const router = Router();

// All routes require authentication
router.use(authenticate);

router.post('/', validate(createBookingSchema), createBooking);
router.get('/', getBookings);
router.get('/:id', getBookingById);
router.put('/:id', updateBooking);
router.post('/:id/cancel', requirePermission('cancel_booking'), cancelBooking);
router.post('/:id/payments', addPayment);

export default router;
