import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createPermission,
  createPermissionSchema,
  deletePermission,
  getPermissionById,
  getPermissions,
  updatePermission,
  updatePermissionSchema,
} from '../controllers/permission.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createPermissionSchema), createPermission);
router.get('/', getPermissions);
router.get('/:id', getPermissionById);
router.put('/:id', validate(updatePermissionSchema), updatePermission);
router.delete('/:id', deletePermission);

export default router;
