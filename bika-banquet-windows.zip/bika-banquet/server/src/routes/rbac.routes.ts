import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  assignPermission,
  assignPermissionSchema,
  assignRole,
  assignRoleSchema,
  listUserPermissions,
  removePermission,
  removePermissionSchema,
  removeRole,
  removeRoleSchema,
  updateRolePermissions,
  updateRolePermissionsSchema,
  updateUserRoles,
  updateUserRolesSchema,
} from '../controllers/rbac.controller';

const router = Router();

router.use(authenticate);

router.post('/assign-role', validate(assignRoleSchema), assignRole);
router.post('/remove-role', validate(removeRoleSchema), removeRole);
router.post('/update-roles', validate(updateUserRolesSchema), updateUserRoles);
router.post(
  '/assign-permission',
  validate(assignPermissionSchema),
  assignPermission
);
router.post(
  '/remove-permission',
  validate(removePermissionSchema),
  removePermission
);
router.post(
  '/update-permissions',
  validate(updateRolePermissionsSchema),
  updateRolePermissions
);
router.get('/user-permissions/:userId', listUserPermissions);

export default router;
