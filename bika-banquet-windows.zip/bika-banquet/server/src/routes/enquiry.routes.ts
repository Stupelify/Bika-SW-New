import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createEnquiry,
  createEnquirySchema,
  deleteEnquiry,
  getEnquiries,
  getEnquiryById,
  updateEnquiry,
  updateEnquirySchema,
} from '../controllers/enquiry.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createEnquirySchema), createEnquiry);
router.get('/', getEnquiries);
router.get('/:id', getEnquiryById);
router.put('/:id', validate(updateEnquirySchema), updateEnquiry);
router.delete('/:id', deleteEnquiry);

export default router;
