import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createBanquet,
  createBanquetSchema,
  deleteBanquet,
  getBanquetById,
  getBanquets,
  updateBanquet,
  updateBanquetSchema,
} from '../controllers/banquet.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createBanquetSchema), createBanquet);
router.get('/', getBanquets);
router.get('/:id', getBanquetById);
router.put('/:id', validate(updateBanquetSchema), updateBanquet);
router.delete('/:id', deleteBanquet);

export default router;
