import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { getDashboardSummary } from '../controllers/analytics.controller';

const router = Router();

router.use(authenticate);

router.get('/dashboard', getDashboardSummary);

export default router;
