import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createItemType,
  createItemTypeSchema,
  deleteItemType,
  getItemTypeById,
  getItemTypes,
  updateItemType,
  updateItemTypeSchema,
} from '../controllers/itemType.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createItemTypeSchema), createItemType);
router.get('/', getItemTypes);
router.get('/:id', getItemTypeById);
router.put('/:id', validate(updateItemTypeSchema), updateItemType);
router.delete('/:id', deleteItemType);

export default router;
