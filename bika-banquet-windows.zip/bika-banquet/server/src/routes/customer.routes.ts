import { Router } from 'express';
import {
  createCustomer,
  getCustomers,
  getCustomerById,
  updateCustomer,
  deleteCustomer,
  sendOTP,
  verifyOTP,
  createCustomerSchema,
  updateCustomerSchema,
} from '../controllers/customer.controller';
import { authenticate, requirePermission } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';

const router = Router();

// OTP routes (public for customer verification)
router.post('/send-otp', sendOTP);
router.post('/verify-otp', verifyOTP);

// Protected routes
router.use(authenticate);

router.post('/', validate(createCustomerSchema), createCustomer);
router.get('/', getCustomers);
router.get('/:id', getCustomerById);
router.put('/:id', validate(updateCustomerSchema), updateCustomer);
router.delete('/:id', requirePermission('delete_customer'), deleteCustomer);

export default router;
