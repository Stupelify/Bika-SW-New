import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import {
  deleteUser,
  getUserById,
  getUsers,
  getUsersSimple,
} from '../controllers/user.controller';

const router = Router();

router.use(authenticate);

router.get('/simple', getUsersSimple);
router.get('/', getUsers);
router.get('/:id', getUserById);
router.delete('/:id', deleteUser);

export default router;
