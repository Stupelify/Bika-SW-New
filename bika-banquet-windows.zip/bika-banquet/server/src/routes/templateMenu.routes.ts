import { Router } from 'express';
import { authenticate } from '../middleware/auth.middleware';
import { validate } from '../middleware/validate.middleware';
import {
  createTemplateMenu,
  createTemplateMenuSchema,
  deleteTemplateMenu,
  getTemplateMenuById,
  getTemplateMenus,
  updateTemplateMenu,
  updateTemplateMenuSchema,
} from '../controllers/templateMenu.controller';

const router = Router();

router.use(authenticate);

router.post('/', validate(createTemplateMenuSchema), createTemplateMenu);
router.get('/', getTemplateMenus);
router.get('/:id', getTemplateMenuById);
router.put('/:id', validate(updateTemplateMenuSchema), updateTemplateMenu);
router.delete('/:id', deleteTemplateMenu);

export default router;
