'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { toast } from 'sonner';
import { Layers, ListChecks, Save, Search, Soup, Trash2 } from 'lucide-react';
import FormPromptModal from '@/components/FormPromptModal';
import SortableHeader from '@/components/SortableHeader';
import {
  SortState,
  TableColumnConfig,
  filterAndSortRows,
  getNextSort,
} from '@/lib/tableUtils';

interface ItemType {
  id: string;
  name: string;
  description?: string | null;
  _count?: {
    items: number;
  };
}

interface Item {
  id: string;
  name: string;
  itemTypeId: string;
  cost?: number | null;
  points?: number | null;
  isVeg: boolean;
  itemType?: {
    id: string;
    name: string;
  };
}

interface TemplateMenu {
  id: string;
  name: string;
  category?: string | null;
  setupCost?: number | null;
  ratePerPlate?: number | null;
  items: Array<{
    id: string;
    item: {
      id: string;
      name: string;
      itemType?: {
        name: string;
      };
    };
  }>;
}

const initialTypeForm = {
  name: '',
  description: '',
};

const initialItemForm = {
  itemTypeId: '',
  name: '',
  cost: '',
  points: '',
  isVeg: true,
};

const initialTemplateForm = {
  name: '',
  category: '',
  setupCost: '',
  ratePerPlate: '',
  itemIds: [] as string[],
};

const initialTypeColumnSearch = {
  name: '',
  itemCount: '',
};

const initialItemColumnSearch = {
  name: '',
  type: '',
  cost: '',
};

const initialTemplateColumnSearch = {
  name: '',
  category: '',
  ratePerPlate: '',
  itemCount: '',
};

export default function MenuPage() {
  const [itemTypes, setItemTypes] = useState<ItemType[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [templateMenus, setTemplateMenus] = useState<TemplateMenu[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingType, setSavingType] = useState(false);
  const [savingItem, setSavingItem] = useState(false);
  const [savingTemplate, setSavingTemplate] = useState(false);
  const [showTypePrompt, setShowTypePrompt] = useState(false);
  const [showItemPrompt, setShowItemPrompt] = useState(false);
  const [showTemplatePrompt, setShowTemplatePrompt] = useState(false);

  const [typeForm, setTypeForm] = useState(initialTypeForm);
  const [itemForm, setItemForm] = useState(initialItemForm);
  const [templateForm, setTemplateForm] = useState(initialTemplateForm);

  const [itemTypeGlobalSearch, setItemTypeGlobalSearch] = useState('');
  const [itemTypeColumnSearch, setItemTypeColumnSearch] = useState(
    initialTypeColumnSearch
  );
  const [itemsGlobalSearch, setItemsGlobalSearch] = useState('');
  const [itemsColumnSearch, setItemsColumnSearch] = useState(initialItemColumnSearch);
  const [templateGlobalSearch, setTemplateGlobalSearch] = useState('');
  const [templateColumnSearch, setTemplateColumnSearch] = useState(
    initialTemplateColumnSearch
  );

  const [itemTypeSort, setItemTypeSort] = useState<SortState>({
    key: 'name',
    direction: 'asc',
  });
  const [itemSort, setItemSort] = useState<SortState>({ key: 'name', direction: 'asc' });
  const [templateSort, setTemplateSort] = useState<SortState>({
    key: 'name',
    direction: 'asc',
  });
  const [activeMenuSection, setActiveMenuSection] = useState<
    'itemType' | 'item' | 'template'
  >('itemType');

  const itemTypeColumns = useMemo<TableColumnConfig<ItemType>[]>(
    () => [
      { key: 'name', accessor: (itemType) => itemType.name },
      { key: 'itemCount', accessor: (itemType) => itemType._count?.items || 0 },
    ],
    []
  );

  const itemColumns = useMemo<TableColumnConfig<Item>[]>(
    () => [
      {
        key: 'name',
        accessor: (item) => `${item.name} ${item.isVeg ? 'Veg' : 'Non-veg'}`,
      },
      { key: 'type', accessor: (item) => item.itemType?.name || '' },
      { key: 'cost', accessor: (item) => item.cost ?? 0 },
    ],
    []
  );

  const templateColumns = useMemo<TableColumnConfig<TemplateMenu>[]>(
    () => [
      { key: 'name', accessor: (menu) => menu.name },
      { key: 'category', accessor: (menu) => menu.category || 'General' },
      { key: 'ratePerPlate', accessor: (menu) => menu.ratePerPlate ?? 0 },
      { key: 'itemCount', accessor: (menu) => menu.items?.length || 0 },
    ],
    []
  );

  const filteredItemTypes = useMemo(
    () =>
      filterAndSortRows(
        itemTypes,
        itemTypeColumns,
        itemTypeGlobalSearch,
        itemTypeColumnSearch,
        itemTypeSort
      ),
    [
      itemTypes,
      itemTypeColumns,
      itemTypeGlobalSearch,
      itemTypeColumnSearch,
      itemTypeSort,
    ]
  );

  const filteredItems = useMemo(
    () =>
      filterAndSortRows(
        items,
        itemColumns,
        itemsGlobalSearch,
        itemsColumnSearch,
        itemSort
      ),
    [items, itemColumns, itemsGlobalSearch, itemsColumnSearch, itemSort]
  );

  const filteredTemplateMenus = useMemo(
    () =>
      filterAndSortRows(
        templateMenus,
        templateColumns,
        templateGlobalSearch,
        templateColumnSearch,
        templateSort
      ),
    [
      templateMenus,
      templateColumns,
      templateGlobalSearch,
      templateColumnSearch,
      templateSort,
    ]
  );

  useEffect(() => {
    void loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [typesRes, itemsRes, templatesRes] = await Promise.all([
        api.getItemTypes({ page: 1, limit: 5000 }),
        api.getItems({ page: 1, limit: 5000 }),
        api.getTemplateMenus({ page: 1, limit: 5000 }),
      ]);

      const types = typesRes.data?.data?.itemTypes || [];
      setItemTypes(types);
      setItems(itemsRes.data?.data?.items || []);
      setTemplateMenus(templatesRes.data?.data?.templateMenus || []);

      if (types.length > 0) {
        setItemForm((prev) => ({ ...prev, itemTypeId: prev.itemTypeId || types[0].id }));
      }
    } catch (error) {
      toast.error('Failed to load menu data');
    } finally {
      setLoading(false);
    }
  };

  const submitType = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!typeForm.name.trim()) {
      toast.error('Item type name is required');
      return;
    }
    try {
      setSavingType(true);
      await api.createItemType({
        name: typeForm.name.trim(),
        description: typeForm.description.trim() || undefined,
      });
      toast.success('Item type created');
      setShowTypePrompt(false);
      setTypeForm(initialTypeForm);
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create item type');
    } finally {
      setSavingType(false);
    }
  };

  const submitItem = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!itemForm.itemTypeId || !itemForm.name.trim()) {
      toast.error('Item type and item name are required');
      return;
    }
    try {
      setSavingItem(true);
      await api.createItem({
        itemTypeId: itemForm.itemTypeId,
        name: itemForm.name.trim(),
        cost: itemForm.cost ? Number(itemForm.cost) : undefined,
        points: itemForm.points ? Number(itemForm.points) : undefined,
        isVeg: itemForm.isVeg,
      });
      toast.success('Item created');
      setShowItemPrompt(false);
      setItemForm((prev) => ({
        ...initialItemForm,
        itemTypeId: prev.itemTypeId,
      }));
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create item');
    } finally {
      setSavingItem(false);
    }
  };

  const submitTemplate = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!templateForm.name.trim()) {
      toast.error('Template menu name is required');
      return;
    }
    try {
      setSavingTemplate(true);
      await api.createTemplateMenu({
        name: templateForm.name.trim(),
        category: templateForm.category.trim() || undefined,
        setupCost: templateForm.setupCost ? Number(templateForm.setupCost) : undefined,
        ratePerPlate: templateForm.ratePerPlate ? Number(templateForm.ratePerPlate) : undefined,
        itemIds: templateForm.itemIds,
      });
      toast.success('Template menu created');
      setShowTemplatePrompt(false);
      setTemplateForm(initialTemplateForm);
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create template menu');
    } finally {
      setSavingTemplate(false);
    }
  };

  const toggleTemplateItem = (itemId: string) => {
    setTemplateForm((prev) => {
      const exists = prev.itemIds.includes(itemId);
      return {
        ...prev,
        itemIds: exists
          ? prev.itemIds.filter((id) => id !== itemId)
          : [...prev.itemIds, itemId],
      };
    });
  };

  const removeItemType = async (id: string) => {
    if (!confirm('Delete this item type?')) return;
    try {
      await api.deleteItemType(id);
      toast.success('Item type deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete item type');
    }
  };

  const removeItem = async (id: string) => {
    if (!confirm('Delete this item?')) return;
    try {
      await api.deleteItem(id);
      toast.success('Item deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete item');
    }
  };

  const removeTemplateMenu = async (id: string) => {
    if (!confirm('Delete this template menu?')) return;
    try {
      await api.deleteTemplateMenu(id);
      toast.success('Template menu deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete template menu');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Menu & Items</h1>
        <p className="text-gray-600 mt-1">
          Manage item categories, individual dishes and reusable template menus.
        </p>
      </div>

      <FormPromptModal
        open={showTypePrompt}
        title="Add Item Type"
        onClose={() => setShowTypePrompt(false)}
        widthClass="max-w-2xl"
      >
        <form className="space-y-4" onSubmit={submitType}>
          <div>
            <label className="label">Name</label>
            <input
              className="input"
              value={typeForm.name}
              onChange={(e) => setTypeForm((prev) => ({ ...prev, name: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea
              className="input min-h-[90px]"
              value={typeForm.description}
              onChange={(e) =>
                setTypeForm((prev) => ({ ...prev, description: e.target.value }))
              }
            />
          </div>
          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowTypePrompt(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingType}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingType ? 'Saving...' : 'Create Type'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <FormPromptModal
        open={showItemPrompt}
        title="Add Item"
        onClose={() => setShowItemPrompt(false)}
        widthClass="max-w-3xl"
      >
        <form className="space-y-4" onSubmit={submitItem}>
          <div>
            <label className="label">Item type</label>
            <select
              className="input"
              value={itemForm.itemTypeId}
              onChange={(e) => setItemForm((prev) => ({ ...prev, itemTypeId: e.target.value }))}
              required
            >
              <option value="">Select item type</option>
              {itemTypes.map((itemType) => (
                <option key={itemType.id} value={itemType.id}>
                  {itemType.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Item name</label>
            <input
              className="input"
              value={itemForm.name}
              onChange={(e) => setItemForm((prev) => ({ ...prev, name: e.target.value }))}
              required
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Cost</label>
              <input
                type="number"
                min={0}
                className="input"
                value={itemForm.cost}
                onChange={(e) => setItemForm((prev) => ({ ...prev, cost: e.target.value }))}
              />
            </div>
            <div>
              <label className="label">Points</label>
              <input
                type="number"
                min={0}
                className="input"
                value={itemForm.points}
                onChange={(e) => setItemForm((prev) => ({ ...prev, points: e.target.value }))}
              />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm text-gray-700">
            <input
              type="checkbox"
              checked={itemForm.isVeg}
              onChange={(e) => setItemForm((prev) => ({ ...prev, isVeg: e.target.checked }))}
            />
            Vegetarian
          </label>
          <div className="form-actions">
            <button type="button" className="btn btn-secondary" onClick={() => setShowItemPrompt(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingItem}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingItem ? 'Saving...' : 'Create Item'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <FormPromptModal
        open={showTemplatePrompt}
        title="Add Template Menu"
        onClose={() => setShowTemplatePrompt(false)}
        widthClass="max-w-3xl"
      >
        <form className="space-y-4" onSubmit={submitTemplate}>
          <div>
            <label className="label">Name</label>
            <input
              className="input"
              value={templateForm.name}
              onChange={(e) =>
                setTemplateForm((prev) => ({ ...prev, name: e.target.value }))
              }
              required
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="label">Setup cost</label>
              <input
                className="input"
                type="number"
                min={0}
                value={templateForm.setupCost}
                onChange={(e) =>
                  setTemplateForm((prev) => ({ ...prev, setupCost: e.target.value }))
                }
              />
            </div>
            <div>
              <label className="label">Rate / plate</label>
              <input
                className="input"
                type="number"
                min={0}
                value={templateForm.ratePerPlate}
                onChange={(e) =>
                  setTemplateForm((prev) => ({ ...prev, ratePerPlate: e.target.value }))
                }
              />
            </div>
          </div>
          <div>
            <label className="label">Category</label>
            <input
              className="input"
              value={templateForm.category}
              onChange={(e) =>
                setTemplateForm((prev) => ({ ...prev, category: e.target.value }))
              }
            />
          </div>
          <div>
            <label className="label">Menu items</label>
            <div className="border border-gray-200 rounded-lg p-3 max-h-40 overflow-y-auto space-y-2">
              {items.length === 0 ? (
                <p className="text-sm text-gray-500">Create items first.</p>
              ) : (
                items.map((item) => (
                  <label key={item.id} className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={templateForm.itemIds.includes(item.id)}
                      onChange={() => toggleTemplateItem(item.id)}
                    />
                    <span>{item.name}</span>
                    <span className="text-xs text-gray-500">({item.itemType?.name})</span>
                  </label>
                ))
              )}
            </div>
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowTemplatePrompt(false)}
            >
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingTemplate}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingTemplate ? 'Saving...' : 'Create Template'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <div className="card p-2">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => setActiveMenuSection('itemType')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeMenuSection === 'itemType'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Item Types
          </button>
          <button
            type="button"
            onClick={() => setActiveMenuSection('item')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeMenuSection === 'item'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Items
          </button>
          <button
            type="button"
            onClick={() => setActiveMenuSection('template')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeMenuSection === 'template'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Template Menus
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className={`card ${activeMenuSection === 'itemType' ? '' : 'hidden'}`}>
          <div className="page-head mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Item types</h2>
            <button
              type="button"
              className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
              onClick={() => setShowTypePrompt(true)}
            >
              <Layers className="w-4 h-4" />
              Add
            </button>
          </div>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="input pl-9"
              value={itemTypeGlobalSearch}
              onChange={(e) => setItemTypeGlobalSearch(e.target.value)}
              placeholder="Overall search in item types..."
            />
          </div>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="table-shell">
              <table className="data-table">
                <thead>
                  <tr className="border-b border-gray-200">
                    <SortableHeader
                      label="Type"
                      sortKey="name"
                      sort={itemTypeSort}
                      onSort={(key) => setItemTypeSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Items"
                      sortKey="itemCount"
                      sort={itemTypeSort}
                      onSort={(key) => setItemTypeSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                  <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search type"
                        value={itemTypeColumnSearch.name}
                        onChange={(e) =>
                          setItemTypeColumnSearch((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search item count"
                        value={itemTypeColumnSearch.itemCount}
                        onChange={(e) =>
                          setItemTypeColumnSearch((prev) => ({
                            ...prev,
                            itemCount: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2" />
                  </tr>
                </thead>
                <tbody>
                  {filteredItemTypes.map((itemType) => (
                    <tr key={itemType.id} className="border-b border-gray-100">
                      <td className="py-3 px-2">
                        <p className="text-sm text-gray-900">{itemType.name}</p>
                      </td>
                      <td className="py-3 px-2 text-sm text-gray-700">{itemType._count?.items || 0}</td>
                      <td className="py-3 px-2 text-right">
                        <button
                          className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                          onClick={() => removeItemType(itemType.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className={`card ${activeMenuSection === 'item' ? '' : 'hidden'}`}>
          <div className="page-head mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Items</h2>
            <button
              type="button"
              className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
              onClick={() => setShowItemPrompt(true)}
            >
              <Soup className="w-4 h-4" />
              Add
            </button>
          </div>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="input pl-9"
              value={itemsGlobalSearch}
              onChange={(e) => setItemsGlobalSearch(e.target.value)}
              placeholder="Overall search in items..."
            />
          </div>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="table-shell">
              <table className="data-table">
                <thead>
                  <tr className="border-b border-gray-200">
                    <SortableHeader
                      label="Item"
                      sortKey="name"
                      sort={itemSort}
                      onSort={(key) => setItemSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Type"
                      sortKey="type"
                      sort={itemSort}
                      onSort={(key) => setItemSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Cost"
                      sortKey="cost"
                      sort={itemSort}
                      onSort={(key) => setItemSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                  <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search item"
                        value={itemsColumnSearch.name}
                        onChange={(e) =>
                          setItemsColumnSearch((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search type"
                        value={itemsColumnSearch.type}
                        onChange={(e) =>
                          setItemsColumnSearch((prev) => ({
                            ...prev,
                            type: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search cost"
                        value={itemsColumnSearch.cost}
                        onChange={(e) =>
                          setItemsColumnSearch((prev) => ({
                            ...prev,
                            cost: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2" />
                  </tr>
                </thead>
                <tbody>
                  {filteredItems.map((item) => (
                    <tr key={item.id} className="border-b border-gray-100">
                      <td className="py-3 px-2">
                        <p className="text-sm text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-500 mt-1">{item.isVeg ? 'Veg' : 'Non-veg'}</p>
                      </td>
                      <td className="py-3 px-2 text-sm text-gray-700">{item.itemType?.name || '-'}</td>
                      <td className="py-3 px-2 text-sm text-gray-700">
                        {item.cost ? `INR ${item.cost.toLocaleString()}` : '-'}
                      </td>
                      <td className="py-3 px-2 text-right">
                        <button
                          className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className={`card ${activeMenuSection === 'template' ? '' : 'hidden'}`}>
          <div className="page-head mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Template menus</h2>
            <button
              type="button"
              className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
              onClick={() => setShowTemplatePrompt(true)}
            >
              <ListChecks className="w-4 h-4" />
              Add
            </button>
          </div>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="input pl-9"
              value={templateGlobalSearch}
              onChange={(e) => setTemplateGlobalSearch(e.target.value)}
              placeholder="Overall search in template menus..."
            />
          </div>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="table-shell">
              <table className="data-table">
                <thead>
                  <tr className="border-b border-gray-200">
                    <SortableHeader
                      label="Name"
                      sortKey="name"
                      sort={templateSort}
                      onSort={(key) => setTemplateSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Category"
                      sortKey="category"
                      sort={templateSort}
                      onSort={(key) => setTemplateSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Rate / Plate"
                      sortKey="ratePerPlate"
                      sort={templateSort}
                      onSort={(key) => setTemplateSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <SortableHeader
                      label="Items"
                      sortKey="itemCount"
                      sort={templateSort}
                      onSort={(key) => setTemplateSort((prev) => getNextSort(prev, key))}
                      className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                    />
                    <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">
                      Actions
                    </th>
                  </tr>
                  <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search name"
                        value={templateColumnSearch.name}
                        onChange={(e) =>
                          setTemplateColumnSearch((prev) => ({
                            ...prev,
                            name: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search category"
                        value={templateColumnSearch.category}
                        onChange={(e) =>
                          setTemplateColumnSearch((prev) => ({
                            ...prev,
                            category: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search rate"
                        value={templateColumnSearch.ratePerPlate}
                        onChange={(e) =>
                          setTemplateColumnSearch((prev) => ({
                            ...prev,
                            ratePerPlate: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2">
                      <input
                        className="input h-9"
                        placeholder="Search item count"
                        value={templateColumnSearch.itemCount}
                        onChange={(e) =>
                          setTemplateColumnSearch((prev) => ({
                            ...prev,
                            itemCount: e.target.value,
                          }))
                        }
                      />
                    </th>
                    <th className="py-2 px-2" />
                  </tr>
                </thead>
                <tbody>
                  {filteredTemplateMenus.map((template) => (
                    <tr key={template.id} className="border-b border-gray-100">
                      <td className="py-3 px-2 text-sm text-gray-900">{template.name}</td>
                      <td className="py-3 px-2 text-sm text-gray-700">{template.category || 'General'}</td>
                      <td className="py-3 px-2 text-sm text-gray-700">
                        INR {(template.ratePerPlate || 0).toLocaleString()}
                      </td>
                      <td className="py-3 px-2 text-sm text-gray-700">{template.items?.length || 0}</td>
                      <td className="py-3 px-2 text-right">
                        <button
                          className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                          onClick={() => removeTemplateMenu(template.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
