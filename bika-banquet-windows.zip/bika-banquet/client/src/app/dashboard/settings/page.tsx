'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { toast } from 'sonner';
import { KeyRound, Save, Settings2, Shield, Trash2, Users } from 'lucide-react';
import FormPromptModal from '@/components/FormPromptModal';

interface UserRow {
  id: string;
  name?: string | null;
  email: string;
  userRoles?: Array<{
    role: {
      id: string;
      name: string;
    };
  }>;
}

interface RoleRow {
  id: string;
  name: string;
  description?: string | null;
  permissions?: Array<{
    permission: {
      id: string;
      name: string;
    };
  }>;
  _count?: {
    userRoles: number;
  };
}

interface PermissionRow {
  id: string;
  name: string;
  description?: string | null;
  _count?: {
    roles: number;
  };
}

const initialRoleForm = {
  name: '',
  description: '',
};

const initialPermissionForm = {
  name: '',
  description: '',
};

export default function SettingsPage() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [permissions, setPermissions] = useState<PermissionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingRole, setSavingRole] = useState(false);
  const [savingPermission, setSavingPermission] = useState(false);
  const [savingUserRoles, setSavingUserRoles] = useState(false);
  const [savingRolePermissions, setSavingRolePermissions] = useState(false);
  const [showRolePrompt, setShowRolePrompt] = useState(false);
  const [showPermissionPrompt, setShowPermissionPrompt] = useState(false);

  const [roleForm, setRoleForm] = useState(initialRoleForm);
  const [permissionForm, setPermissionForm] = useState(initialPermissionForm);

  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState('');
  const [selectedPermissionIds, setSelectedPermissionIds] = useState<string[]>([]);
  const [activeSettingsSection, setActiveSettingsSection] = useState<
    'access' | 'users' | 'roles' | 'permissions'
  >('access');

  useEffect(() => {
    void loadData();
  }, []);

  useEffect(() => {
    if (!selectedUserId && users.length > 0) {
      setSelectedUserId(users[0].id);
    }
  }, [users, selectedUserId]);

  useEffect(() => {
    if (!selectedRoleId && roles.length > 0) {
      setSelectedRoleId(roles[0].id);
    }
  }, [roles, selectedRoleId]);

  const selectedUser = useMemo(
    () => users.find((user) => user.id === selectedUserId),
    [users, selectedUserId]
  );

  const selectedRole = useMemo(
    () => roles.find((role) => role.id === selectedRoleId),
    [roles, selectedRoleId]
  );

  useEffect(() => {
    if (!selectedUser) return;
    setSelectedRoleIds(selectedUser.userRoles?.map((ur) => ur.role.id) || []);
  }, [selectedUser]);

  useEffect(() => {
    if (!selectedRole) return;
    setSelectedPermissionIds(selectedRole.permissions?.map((rp) => rp.permission.id) || []);
  }, [selectedRole]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [usersRes, rolesRes, permissionsRes] = await Promise.all([
        api.getUsers({ page: 1, limit: 200 }),
        api.getRoles(),
        api.getPermissions(),
      ]);
      setUsers(usersRes.data?.data?.users || []);
      setRoles(rolesRes.data?.data?.roles || []);
      setPermissions(permissionsRes.data?.data?.permissions || []);
    } catch (error) {
      toast.error('Failed to load settings data');
    } finally {
      setLoading(false);
    }
  };

  const createRole = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!roleForm.name.trim()) {
      toast.error('Role name is required');
      return;
    }
    try {
      setSavingRole(true);
      await api.createRole({
        name: roleForm.name.trim(),
        description: roleForm.description.trim() || undefined,
      });
      toast.success('Role created');
      setShowRolePrompt(false);
      setRoleForm(initialRoleForm);
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create role');
    } finally {
      setSavingRole(false);
    }
  };

  const createPermission = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!permissionForm.name.trim()) {
      toast.error('Permission name is required');
      return;
    }
    try {
      setSavingPermission(true);
      await api.createPermission({
        name: permissionForm.name.trim(),
        description: permissionForm.description.trim() || undefined,
      });
      toast.success('Permission created');
      setShowPermissionPrompt(false);
      setPermissionForm(initialPermissionForm);
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create permission');
    } finally {
      setSavingPermission(false);
    }
  };

  const updateUserRoles = async () => {
    if (!selectedUserId) {
      toast.error('Select a user first');
      return;
    }
    try {
      setSavingUserRoles(true);
      await api.updateUserRoles({
        userId: selectedUserId,
        roleIds: selectedRoleIds,
      });
      toast.success('User roles updated');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to update user roles');
    } finally {
      setSavingUserRoles(false);
    }
  };

  const updateRolePermissions = async () => {
    if (!selectedRoleId) {
      toast.error('Select a role first');
      return;
    }
    try {
      setSavingRolePermissions(true);
      await api.updateRolePermissions({
        roleId: selectedRoleId,
        permissionIds: selectedPermissionIds,
      });
      toast.success('Role permissions updated');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to update permissions');
    } finally {
      setSavingRolePermissions(false);
    }
  };

  const toggleRole = (roleId: string) => {
    setSelectedRoleIds((prev) =>
      prev.includes(roleId) ? prev.filter((id) => id !== roleId) : [...prev, roleId]
    );
  };

  const togglePermission = (permissionId: string) => {
    setSelectedPermissionIds((prev) =>
      prev.includes(permissionId)
        ? prev.filter((id) => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  const removeUser = async (id: string) => {
    if (!confirm('Delete this user?')) return;
    try {
      await api.deleteUser(id);
      toast.success('User deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete user');
    }
  };

  const removeRole = async (id: string) => {
    if (!confirm('Delete this role?')) return;
    try {
      await api.deleteRole(id);
      toast.success('Role deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete role');
    }
  };

  const removePermission = async (id: string) => {
    if (!confirm('Delete this permission?')) return;
    try {
      await api.deletePermission(id);
      toast.success('Permission deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete permission');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings & Access</h1>
        <p className="text-gray-600 mt-1">
          Manage users, roles and permissions with role-based access control.
        </p>
      </div>

      <FormPromptModal
        open={showRolePrompt}
        title="Create Role"
        onClose={() => setShowRolePrompt(false)}
        widthClass="max-w-2xl"
      >
        <form className="space-y-4" onSubmit={createRole}>
          <div>
            <label className="label">Role name</label>
            <input
              className="input"
              value={roleForm.name}
              onChange={(e) => setRoleForm((prev) => ({ ...prev, name: e.target.value }))}
              required
            />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea
              className="input min-h-[90px]"
              value={roleForm.description}
              onChange={(e) =>
                setRoleForm((prev) => ({ ...prev, description: e.target.value }))
              }
            />
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowRolePrompt(false)}
            >
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingRole}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingRole ? 'Saving...' : 'Create Role'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <FormPromptModal
        open={showPermissionPrompt}
        title="Create Permission"
        onClose={() => setShowPermissionPrompt(false)}
        widthClass="max-w-2xl"
      >
        <form className="space-y-4" onSubmit={createPermission}>
          <div>
            <label className="label">Permission key</label>
            <input
              className="input"
              value={permissionForm.name}
              onChange={(e) =>
                setPermissionForm((prev) => ({ ...prev, name: e.target.value }))
              }
              placeholder="manage_bookings"
              required
            />
          </div>
          <div>
            <label className="label">Description</label>
            <textarea
              className="input min-h-[90px]"
              value={permissionForm.description}
              onChange={(e) =>
                setPermissionForm((prev) => ({ ...prev, description: e.target.value }))
              }
            />
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowPermissionPrompt(false)}
            >
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingPermission}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingPermission ? 'Saving...' : 'Create Permission'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <div className="card p-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => setActiveSettingsSection('access')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeSettingsSection === 'access'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Access Mapping
          </button>
          <button
            type="button"
            onClick={() => setActiveSettingsSection('users')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeSettingsSection === 'users'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Users
          </button>
          <button
            type="button"
            onClick={() => setActiveSettingsSection('roles')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeSettingsSection === 'roles'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Roles
          </button>
          <button
            type="button"
            onClick={() => setActiveSettingsSection('permissions')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeSettingsSection === 'permissions'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Permissions
          </button>
        </div>
      </div>

      <div
        className={`grid grid-cols-1 xl:grid-cols-2 gap-6 ${
          activeSettingsSection === 'access' ? '' : 'hidden'
        }`}
      >
        <div className="card space-y-4">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-primary-600" />
            <h2 className="text-lg font-semibold text-gray-900">Assign roles to user</h2>
          </div>
          <div>
            <label className="label">User</label>
            <select
              className="input"
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
            >
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name || 'Unnamed'} ({user.email})
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {roles.map((role) => (
              <label key={role.id} className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={selectedRoleIds.includes(role.id)}
                  onChange={() => toggleRole(role.id)}
                />
                {role.name}
              </label>
            ))}
          </div>
          <div className="flex justify-end">
            <button
              className="btn btn-primary w-full sm:w-auto"
              onClick={updateUserRoles}
              disabled={savingUserRoles}
            >
              {savingUserRoles ? 'Saving...' : 'Save User Roles'}
            </button>
          </div>
        </div>

        <div className="card space-y-4">
          <div className="flex items-center gap-2">
            <Settings2 className="w-4 h-4 text-primary-600" />
            <h2 className="text-lg font-semibold text-gray-900">Assign permissions to role</h2>
          </div>
          <div>
            <label className="label">Role</label>
            <select
              className="input"
              value={selectedRoleId}
              onChange={(e) => setSelectedRoleId(e.target.value)}
            >
              {roles.map((role) => (
                <option key={role.id} value={role.id}>
                  {role.name}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-52 overflow-y-auto border border-gray-200 rounded-lg p-3">
            {permissions.map((permission) => (
              <label key={permission.id} className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={selectedPermissionIds.includes(permission.id)}
                  onChange={() => togglePermission(permission.id)}
                />
                {permission.name}
              </label>
            ))}
          </div>
          <div className="flex justify-end">
            <button
              className="btn btn-primary w-full sm:w-auto"
              onClick={updateRolePermissions}
              disabled={savingRolePermissions}
            >
              {savingRolePermissions ? 'Saving...' : 'Save Role Permissions'}
            </button>
          </div>
        </div>
      </div>

      <div
        className={`grid grid-cols-1 xl:grid-cols-3 gap-6 ${
          activeSettingsSection === 'access' ? 'hidden' : ''
        }`}
      >
        <div className={`card ${activeSettingsSection === 'users' ? '' : 'hidden'}`}>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Users</h2>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="space-y-3">
              {users.map((user) => (
                <div key={user.id} className="border border-gray-200 rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{user.name || 'Unnamed user'}</p>
                      <p className="text-xs text-gray-500 mt-1">{user.email}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {(user.userRoles || []).map((ur) => ur.role.name).join(', ') || 'No roles'}
                      </p>
                    </div>
                    <button
                      className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      onClick={() => removeUser(user.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className={`card ${activeSettingsSection === 'roles' ? '' : 'hidden'}`}>
          <div className="page-head mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Roles</h2>
            <button
              type="button"
              className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
              onClick={() => setShowRolePrompt(true)}
            >
              <Shield className="w-4 h-4" />
              Add
            </button>
          </div>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="space-y-3">
              {roles.map((role) => (
                <div key={role.id} className="border border-gray-200 rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{role.name}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {role.permissions?.length || 0} permissions • {role._count?.userRoles || 0} users
                      </p>
                    </div>
                    <button
                      className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      onClick={() => removeRole(role.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className={`card ${activeSettingsSection === 'permissions' ? '' : 'hidden'}`}>
          <div className="page-head mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Permissions</h2>
            <button
              type="button"
              className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
              onClick={() => setShowPermissionPrompt(true)}
            >
              <KeyRound className="w-4 h-4" />
              Add
            </button>
          </div>
          {loading ? (
            <div className="py-10 flex items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
            </div>
          ) : (
            <div className="space-y-3">
              {permissions.map((permission) => (
                <div key={permission.id} className="border border-gray-200 rounded-lg p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{permission.name}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {(permission._count?.roles || 0).toLocaleString()} linked roles
                      </p>
                    </div>
                    <button
                      className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                      onClick={() => removePermission(permission.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
