'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { toast } from 'sonner';
import { Building2, Landmark, Save, Search, Trash2 } from 'lucide-react';
import FormPromptModal from '@/components/FormPromptModal';
import SortableHeader from '@/components/SortableHeader';
import {
  SortState,
  TableColumnConfig,
  filterAndSortRows,
  getNextSort,
} from '@/lib/tableUtils';

interface Banquet {
  id: string;
  name: string;
  location: string;
  city?: string | null;
  state?: string | null;
  phone?: string | null;
  halls?: Array<{ id: string }>;
}

interface Hall {
  id: string;
  name: string;
  capacity: number;
  floatingCapacity?: number | null;
  basePrice?: number | null;
  location?: string | null;
  rate?: string | null;
  banquet?: {
    id: string;
    name: string;
  } | null;
}

const initialBanquetForm = {
  name: '',
  location: '',
  city: '',
  state: '',
  phone: '',
};

const initialHallForm = {
  name: '',
  capacity: '200',
  floatingCapacity: '',
  basePrice: '',
  location: '',
  rate: '',
  banquetId: '',
};

const initialBanquetColumnSearch = {
  name: '',
  location: '',
  halls: '',
};

const initialHallColumnSearch = {
  name: '',
  capacity: '',
  pricing: '',
};

export default function HallsPage() {
  const [banquets, setBanquets] = useState<Banquet[]>([]);
  const [halls, setHalls] = useState<Hall[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingBanquet, setSavingBanquet] = useState(false);
  const [savingHall, setSavingHall] = useState(false);
  const [showBanquetPrompt, setShowBanquetPrompt] = useState(false);
  const [showHallPrompt, setShowHallPrompt] = useState(false);
  const [banquetForm, setBanquetForm] = useState(initialBanquetForm);
  const [hallForm, setHallForm] = useState(initialHallForm);
  const [banquetGlobalSearch, setBanquetGlobalSearch] = useState('');
  const [banquetColumnSearch, setBanquetColumnSearch] = useState(
    initialBanquetColumnSearch
  );
  const [hallGlobalSearch, setHallGlobalSearch] = useState('');
  const [hallColumnSearch, setHallColumnSearch] = useState(initialHallColumnSearch);
  const [banquetSort, setBanquetSort] = useState<SortState>({
    key: 'name',
    direction: 'asc',
  });
  const [hallSort, setHallSort] = useState<SortState>({
    key: 'name',
    direction: 'asc',
  });
  const [activeVenueSection, setActiveVenueSection] = useState<'banquet' | 'hall'>(
    'banquet'
  );

  const banquetColumns = useMemo<TableColumnConfig<Banquet>[]>(
    () => [
      { key: 'name', accessor: (banquet) => banquet.name },
      {
        key: 'location',
        accessor: (banquet) =>
          [banquet.location, banquet.city, banquet.state].filter(Boolean).join(', '),
      },
      { key: 'halls', accessor: (banquet) => banquet.halls?.length || 0 },
    ],
    []
  );

  const hallColumns = useMemo<TableColumnConfig<Hall>[]>(
    () => [
      {
        key: 'name',
        accessor: (hall) => `${hall.name} ${hall.banquet?.name || 'No banquet'}`,
      },
      {
        key: 'capacity',
        accessor: (hall) =>
          `${hall.capacity}${hall.floatingCapacity ? ` ${hall.floatingCapacity}` : ''}`,
      },
      {
        key: 'pricing',
        accessor: (hall) => hall.basePrice ?? hall.rate ?? 0,
      },
    ],
    []
  );

  const filteredBanquets = useMemo(
    () =>
      filterAndSortRows(
        banquets,
        banquetColumns,
        banquetGlobalSearch,
        banquetColumnSearch,
        banquetSort
      ),
    [
      banquets,
      banquetColumns,
      banquetGlobalSearch,
      banquetColumnSearch,
      banquetSort,
    ]
  );

  const filteredHalls = useMemo(
    () =>
      filterAndSortRows(halls, hallColumns, hallGlobalSearch, hallColumnSearch, hallSort),
    [halls, hallColumns, hallGlobalSearch, hallColumnSearch, hallSort]
  );

  useEffect(() => {
    void loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [banquetsRes, hallsRes] = await Promise.all([
        api.getBanquets({ page: 1, limit: 2000 }),
        api.getHalls({ page: 1, limit: 2000 }),
      ]);
      const banquetRows = banquetsRes.data?.data?.banquets || [];
      setBanquets(banquetRows);
      setHalls(hallsRes.data?.data?.halls || []);
      if (banquetRows.length > 0) {
        setHallForm((prev) => ({ ...prev, banquetId: prev.banquetId || banquetRows[0].id }));
      }
    } catch (error) {
      toast.error('Failed to load venue data');
    } finally {
      setLoading(false);
    }
  };

  const createBanquet = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!banquetForm.name.trim() || !banquetForm.location.trim()) {
      toast.error('Banquet name and location are required');
      return;
    }
    try {
      setSavingBanquet(true);
      await api.createBanquet({
        name: banquetForm.name.trim(),
        location: banquetForm.location.trim(),
        city: banquetForm.city.trim() || undefined,
        state: banquetForm.state.trim() || undefined,
        phone: banquetForm.phone.trim() || undefined,
      });
      toast.success('Banquet created');
      setShowBanquetPrompt(false);
      setBanquetForm(initialBanquetForm);
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create banquet');
    } finally {
      setSavingBanquet(false);
    }
  };

  const createHall = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!hallForm.name.trim() || !hallForm.capacity) {
      toast.error('Hall name and capacity are required');
      return;
    }
    try {
      setSavingHall(true);
      await api.createHall({
        name: hallForm.name.trim(),
        capacity: Number(hallForm.capacity),
        floatingCapacity: hallForm.floatingCapacity
          ? Number(hallForm.floatingCapacity)
          : undefined,
        basePrice: hallForm.basePrice ? Number(hallForm.basePrice) : undefined,
        location: hallForm.location.trim() || undefined,
        rate: hallForm.rate.trim() || undefined,
        banquetId: hallForm.banquetId || undefined,
      });
      toast.success('Hall created');
      setShowHallPrompt(false);
      setHallForm((prev) => ({
        ...initialHallForm,
        banquetId: prev.banquetId,
      }));
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create hall');
    } finally {
      setSavingHall(false);
    }
  };

  const deleteBanquet = async (id: string) => {
    if (!confirm('Delete this banquet?')) return;
    try {
      await api.deleteBanquet(id);
      toast.success('Banquet deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete banquet');
    }
  };

  const deleteHall = async (id: string) => {
    if (!confirm('Delete this hall?')) return;
    try {
      await api.deleteHall(id);
      toast.success('Hall deleted');
      await loadData();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete hall');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Venues</h1>
        <p className="text-gray-600 mt-1">
          Maintain banquet properties and hall inventory in separate tables.
        </p>
      </div>

      <FormPromptModal
        open={showBanquetPrompt}
        title="Add Banquet"
        onClose={() => setShowBanquetPrompt(false)}
        widthClass="max-w-3xl"
      >
        <form className="space-y-4" onSubmit={createBanquet}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Name</label>
              <input
                className="input"
                value={banquetForm.name}
                onChange={(e) =>
                  setBanquetForm((prev) => ({ ...prev, name: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="label">Location</label>
              <input
                className="input"
                value={banquetForm.location}
                onChange={(e) =>
                  setBanquetForm((prev) => ({ ...prev, location: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="label">City</label>
              <input
                className="input"
                value={banquetForm.city}
                onChange={(e) =>
                  setBanquetForm((prev) => ({ ...prev, city: e.target.value }))
                }
              />
            </div>
            <div>
              <label className="label">State</label>
              <input
                className="input"
                value={banquetForm.state}
                onChange={(e) =>
                  setBanquetForm((prev) => ({ ...prev, state: e.target.value }))
                }
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Phone</label>
              <input
                className="input"
                value={banquetForm.phone}
                onChange={(e) =>
                  setBanquetForm((prev) => ({ ...prev, phone: e.target.value }))
                }
              />
            </div>
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowBanquetPrompt(false)}
            >
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingBanquet}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingBanquet ? 'Saving...' : 'Create Banquet'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <FormPromptModal
        open={showHallPrompt}
        title="Add Hall"
        onClose={() => setShowHallPrompt(false)}
        widthClass="max-w-3xl"
      >
        <form className="space-y-4" onSubmit={createHall}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Hall name</label>
              <input
                className="input"
                value={hallForm.name}
                onChange={(e) => setHallForm((prev) => ({ ...prev, name: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="label">Banquet</label>
              <select
                className="input"
                value={hallForm.banquetId}
                onChange={(e) => setHallForm((prev) => ({ ...prev, banquetId: e.target.value }))}
              >
                <option value="">No banquet</option>
                {banquets.map((banquet) => (
                  <option key={banquet.id} value={banquet.id}>
                    {banquet.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Capacity</label>
              <input
                className="input"
                type="number"
                min={1}
                value={hallForm.capacity}
                onChange={(e) => setHallForm((prev) => ({ ...prev, capacity: e.target.value }))}
                required
              />
            </div>
            <div>
              <label className="label">Floating capacity</label>
              <input
                className="input"
                type="number"
                min={0}
                value={hallForm.floatingCapacity}
                onChange={(e) =>
                  setHallForm((prev) => ({ ...prev, floatingCapacity: e.target.value }))
                }
              />
            </div>
            <div>
              <label className="label">Base price</label>
              <input
                className="input"
                type="number"
                min={0}
                value={hallForm.basePrice}
                onChange={(e) => setHallForm((prev) => ({ ...prev, basePrice: e.target.value }))}
              />
            </div>
            <div>
              <label className="label">Legacy rate</label>
              <input
                className="input"
                value={hallForm.rate}
                onChange={(e) => setHallForm((prev) => ({ ...prev, rate: e.target.value }))}
              />
            </div>
            <div className="md:col-span-2">
              <label className="label">Location details</label>
              <input
                className="input"
                value={hallForm.location}
                onChange={(e) => setHallForm((prev) => ({ ...prev, location: e.target.value }))}
              />
            </div>
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowHallPrompt(false)}
            >
              Cancel
            </button>
            <button className="btn btn-primary" type="submit" disabled={savingHall}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {savingHall ? 'Saving...' : 'Create Hall'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <div className="card p-2">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setActiveVenueSection('banquet')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeVenueSection === 'banquet'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Banquet
          </button>
          <button
            type="button"
            onClick={() => setActiveVenueSection('hall')}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              activeVenueSection === 'hall'
                ? 'bg-primary-600 text-white shadow'
                : 'bg-white text-gray-700 border border-gray-200 hover:border-primary-200'
            }`}
          >
            Hall
          </button>
        </div>
      </div>

      <div className="card">
        {activeVenueSection === 'banquet' ? (
          <>
            <div className="page-head mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Banquet table</h2>
              <button
                type="button"
                className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
                onClick={() => setShowBanquetPrompt(true)}
              >
                <Landmark className="w-4 h-4" />
                Add
              </button>
            </div>

            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                className="input pl-9"
                value={banquetGlobalSearch}
                onChange={(e) => setBanquetGlobalSearch(e.target.value)}
                placeholder="Overall search in banquet table..."
              />
            </div>

            {loading ? (
              <div className="py-10 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
              </div>
            ) : filteredBanquets.length === 0 ? (
              <p className="text-gray-500 text-sm">No banquets found.</p>
            ) : (
              <div className="table-shell">
                <table className="data-table">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <SortableHeader
                        label="Name"
                        sortKey="name"
                        sort={banquetSort}
                        onSort={(key) => setBanquetSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <SortableHeader
                        label="Location"
                        sortKey="location"
                        sort={banquetSort}
                        onSort={(key) => setBanquetSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <SortableHeader
                        label="Halls"
                        sortKey="halls"
                        sort={banquetSort}
                        onSort={(key) => setBanquetSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">
                        Actions
                      </th>
                    </tr>
                    <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search name"
                          value={banquetColumnSearch.name}
                          onChange={(e) =>
                            setBanquetColumnSearch((prev) => ({
                              ...prev,
                              name: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search location"
                          value={banquetColumnSearch.location}
                          onChange={(e) =>
                            setBanquetColumnSearch((prev) => ({
                              ...prev,
                              location: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search halls"
                          value={banquetColumnSearch.halls}
                          onChange={(e) =>
                            setBanquetColumnSearch((prev) => ({
                              ...prev,
                              halls: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2" />
                    </tr>
                  </thead>
                  <tbody>
                    {filteredBanquets.map((banquet) => (
                      <tr key={banquet.id} className="border-b border-gray-100">
                        <td className="py-3 px-2 text-sm text-gray-900">{banquet.name}</td>
                        <td className="py-3 px-2 text-sm text-gray-700">
                          {[banquet.location, banquet.city, banquet.state]
                            .filter(Boolean)
                            .join(', ')}
                        </td>
                        <td className="py-3 px-2 text-sm text-gray-700">
                          {banquet.halls?.length || 0}
                        </td>
                        <td className="py-3 px-2 text-right">
                          <button
                            className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                            onClick={() => deleteBanquet(banquet.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="page-head mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Hall table</h2>
              <button
                type="button"
                className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
                onClick={() => setShowHallPrompt(true)}
              >
                <Building2 className="w-4 h-4" />
                Add
              </button>
            </div>

            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                className="input pl-9"
                value={hallGlobalSearch}
                onChange={(e) => setHallGlobalSearch(e.target.value)}
                placeholder="Overall search in hall table..."
              />
            </div>

            {loading ? (
              <div className="py-10 flex items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
              </div>
            ) : filteredHalls.length === 0 ? (
              <p className="text-gray-500 text-sm">No halls found.</p>
            ) : (
              <div className="table-shell">
                <table className="data-table">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <SortableHeader
                        label="Hall"
                        sortKey="name"
                        sort={hallSort}
                        onSort={(key) => setHallSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <SortableHeader
                        label="Capacity"
                        sortKey="capacity"
                        sort={hallSort}
                        onSort={(key) => setHallSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <SortableHeader
                        label="Pricing"
                        sortKey="pricing"
                        sort={hallSort}
                        onSort={(key) => setHallSort((prev) => getNextSort(prev, key))}
                        className="text-left py-3 px-2 text-sm font-semibold text-gray-700"
                      />
                      <th className="text-right py-3 px-2 text-sm font-semibold text-gray-700">
                        Actions
                      </th>
                    </tr>
                    <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search hall"
                          value={hallColumnSearch.name}
                          onChange={(e) =>
                            setHallColumnSearch((prev) => ({
                              ...prev,
                              name: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search capacity"
                          value={hallColumnSearch.capacity}
                          onChange={(e) =>
                            setHallColumnSearch((prev) => ({
                              ...prev,
                              capacity: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2">
                        <input
                          className="input h-9"
                          placeholder="Search pricing"
                          value={hallColumnSearch.pricing}
                          onChange={(e) =>
                            setHallColumnSearch((prev) => ({
                              ...prev,
                              pricing: e.target.value,
                            }))
                          }
                        />
                      </th>
                      <th className="py-2 px-2" />
                    </tr>
                  </thead>
                  <tbody>
                    {filteredHalls.map((hall) => (
                      <tr key={hall.id} className="border-b border-gray-100">
                        <td className="py-3 px-2">
                          <p className="text-sm text-gray-900">{hall.name}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {hall.banquet?.name || 'No banquet'}
                          </p>
                        </td>
                        <td className="py-3 px-2 text-sm text-gray-700">
                          {hall.capacity}
                          {hall.floatingCapacity ? ` / ${hall.floatingCapacity}` : ''}
                        </td>
                        <td className="py-3 px-2 text-sm text-gray-700">
                          {hall.basePrice
                            ? `INR ${hall.basePrice.toLocaleString()}`
                            : hall.rate || '-'}
                        </td>
                        <td className="py-3 px-2 text-right">
                          <button
                            className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                            onClick={() => deleteHall(hall.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
