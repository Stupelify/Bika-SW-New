'use client';

import { useEffect, useMemo, useState } from 'react';
import { CalendarCheck, Plus, Save, Search, Users } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import FormPromptModal from '@/components/FormPromptModal';
import SortableHeader from '@/components/SortableHeader';
import {
  SortState,
  TableColumnConfig,
  filterAndSortRows,
  getNextSort,
} from '@/lib/tableUtils';

interface Booking {
  id: string;
  functionName: string;
  functionType: string;
  functionDate: string;
  expectedGuests: number;
  status: string;
  isQuotation: boolean;
  grandTotal: number;
  customer: {
    name: string;
    phone: string;
  };
}

interface CustomerOption {
  id: string;
  name: string;
  phone: string;
}

interface BookingFormData {
  customerId: string;
  functionName: string;
  functionType: string;
  functionDate: string;
  functionTime: string;
  expectedGuests: string;
  isQuotation: boolean;
}

const initialFormData: BookingFormData = {
  customerId: '',
  functionName: '',
  functionType: '',
  functionDate: '',
  functionTime: '19:00',
  expectedGuests: '100',
  isQuotation: false,
};

const initialColumnSearch = {
  functionName: '',
  customer: '',
  functionDate: '',
  expectedGuests: '',
  status: '',
  grandTotal: '',
};

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState(initialColumnSearch);
  const [sort, setSort] = useState<SortState>({
    key: 'functionName',
    direction: 'asc',
  });
  const [formData, setFormData] = useState<BookingFormData>(initialFormData);

  const tableColumns = useMemo<TableColumnConfig<Booking>[]>(
    () => [
      {
        key: 'functionName',
        accessor: (booking) => `${booking.functionName} ${booking.functionType}`,
      },
      {
        key: 'customer',
        accessor: (booking) =>
          `${booking.customer?.name ?? ''} ${booking.customer?.phone ?? ''}`,
      },
      {
        key: 'functionDate',
        accessor: (booking) => booking.functionDate,
      },
      {
        key: 'expectedGuests',
        accessor: (booking) => booking.expectedGuests,
      },
      {
        key: 'status',
        accessor: (booking) =>
          booking.isQuotation ? 'Quotation' : booking.status,
      },
      {
        key: 'grandTotal',
        accessor: (booking) => booking.grandTotal ?? 0,
      },
    ],
    []
  );

  const filteredBookings = useMemo(
    () => filterAndSortRows(bookings, tableColumns, globalSearch, columnSearch, sort),
    [bookings, tableColumns, globalSearch, columnSearch, sort]
  );

  useEffect(() => {
    void loadBookings();
  }, []);

  useEffect(() => {
    void loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const response = await api.getCustomers({ page: 1, limit: 5000 });
      const rows = response.data?.data?.customers || [];
      setCustomers(rows);
      if (rows.length > 0) {
        setFormData((prev) => ({ ...prev, customerId: prev.customerId || rows[0].id }));
      }
    } catch (error) {
      toast.error('Failed to load customers for booking form');
    }
  };

  const loadBookings = async () => {
    try {
      setLoading(true);
      const response = await api.getBookings({
        page: 1,
        limit: 5000,
      });
      setBookings(response.data.data.bookings || []);
    } catch (error) {
      toast.error('Failed to load bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleColumnSearch = (key: keyof typeof initialColumnSearch, value: string) => {
    setColumnSearch((prev) => ({ ...prev, [key]: value }));
  };

  const handleCreateBooking = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (
      !formData.customerId ||
      !formData.functionName.trim() ||
      !formData.functionType.trim() ||
      !formData.functionDate ||
      !formData.functionTime ||
      !formData.expectedGuests
    ) {
      toast.error('Please fill all required booking fields');
      return;
    }

    try {
      setSaving(true);
      await api.createBooking({
        customerId: formData.customerId,
        functionName: formData.functionName.trim(),
        functionType: formData.functionType.trim(),
        functionDate: formData.functionDate,
        functionTime: formData.functionTime,
        expectedGuests: Number(formData.expectedGuests),
        isQuotation: formData.isQuotation,
      });
      toast.success('Booking created successfully');
      setShowCreateForm(false);
      setFormData((prev) => ({
        ...initialFormData,
        customerId: prev.customerId,
      }));
      await loadBookings();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create booking');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="page-head gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Bookings</h1>
          <p className="text-gray-600 mt-1">
            View booking records and quotation statuses.
          </p>
        </div>
        <button
          onClick={() => setShowCreateForm(true)}
          className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
          disabled={customers.length === 0}
        >
          <Plus className="w-4 h-4" />
          Add Booking
        </button>
      </div>

      {customers.length === 0 && (
        <div className="card border-amber-200 bg-amber-50">
          <p className="text-sm text-amber-800">
            Add at least one customer before creating bookings.
          </p>
        </div>
      )}

      <FormPromptModal
        open={showCreateForm}
        title="Create Booking"
        onClose={() => setShowCreateForm(false)}
      >
        <form onSubmit={handleCreateBooking} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="label">Customer *</label>
              <select
                className="input"
                value={formData.customerId}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, customerId: e.target.value }))
                }
                required
              >
                {customers.map((customer) => (
                  <option key={customer.id} value={customer.id}>
                    {customer.name} ({customer.phone})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Function name *</label>
              <input
                className="input"
                value={formData.functionName}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionName: e.target.value }))
                }
                placeholder="Wedding Reception"
                required
              />
            </div>
            <div>
              <label className="label">Function type *</label>
              <input
                className="input"
                value={formData.functionType}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionType: e.target.value }))
                }
                placeholder="Wedding / Corporate"
                required
              />
            </div>
            <div>
              <label className="label">Expected guests *</label>
              <input
                className="input"
                type="number"
                min={1}
                value={formData.expectedGuests}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, expectedGuests: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="label">Function date *</label>
              <input
                className="input"
                type="date"
                value={formData.functionDate}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionDate: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="label">Function time *</label>
              <input
                className="input"
                type="time"
                value={formData.functionTime}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionTime: e.target.value }))
                }
                required
              />
            </div>
            <label className="text-sm text-gray-700 flex items-center gap-2 mt-8">
              <input
                type="checkbox"
                checked={formData.isQuotation}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, isQuotation: e.target.checked }))
                }
              />
              Save as quotation
            </label>
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowCreateForm(false)}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {saving ? 'Saving...' : 'Create Booking'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <div className="card">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            placeholder="Overall search across all booking columns..."
            className="input pl-10"
          />
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : filteredBookings.length === 0 ? (
          <div className="text-center py-12">
            <CalendarCheck className="w-10 h-10 mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500">No bookings found</p>
          </div>
        ) : (
          <div className="table-shell">
            <table className="data-table">
              <thead>
                <tr className="border-b border-gray-200">
                  <SortableHeader
                    label="Function"
                    sortKey="functionName"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Customer"
                    sortKey="customer"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Date"
                    sortKey="functionDate"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Guests"
                    sortKey="expectedGuests"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Status"
                    sortKey="status"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Amount"
                    sortKey="grandTotal"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                    className="text-right py-3 px-4 text-sm font-semibold text-gray-700"
                  />
                </tr>
                <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search function"
                      value={columnSearch.functionName}
                      onChange={(e) => handleColumnSearch('functionName', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search customer"
                      value={columnSearch.customer}
                      onChange={(e) => handleColumnSearch('customer', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search date"
                      value={columnSearch.functionDate}
                      onChange={(e) => handleColumnSearch('functionDate', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search guests"
                      value={columnSearch.expectedGuests}
                      onChange={(e) => handleColumnSearch('expectedGuests', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search status"
                      value={columnSearch.status}
                      onChange={(e) => handleColumnSearch('status', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9 text-right"
                      placeholder="Search amount"
                      value={columnSearch.grandTotal}
                      onChange={(e) => handleColumnSearch('grandTotal', e.target.value)}
                    />
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredBookings.map((booking) => (
                  <tr
                    key={booking.id}
                    className="border-b border-gray-100 hover:bg-gray-50"
                  >
                    <td className="py-4 px-4">
                      <p className="font-medium text-gray-900">{booking.functionName}</p>
                      <p className="text-xs text-gray-500 mt-1">{booking.functionType}</p>
                    </td>
                    <td className="py-4 px-4">
                      <p className="text-sm text-gray-900">{booking.customer?.name}</p>
                      <p className="text-xs text-gray-500 mt-1">{booking.customer?.phone}</p>
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-700">
                      {new Date(booking.functionDate).toLocaleDateString()}
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-700">
                      <span className="inline-flex items-center gap-1">
                        <Users className="w-4 h-4 text-gray-500" />
                        {booking.expectedGuests}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          booking.isQuotation
                            ? 'bg-amber-100 text-amber-800'
                            : booking.status === 'cancelled'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-green-100 text-green-700'
                        }`}
                      >
                        {booking.isQuotation ? 'Quotation' : booking.status}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-right text-sm font-medium text-gray-900">
                      ₹{(booking.grandTotal || 0).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
