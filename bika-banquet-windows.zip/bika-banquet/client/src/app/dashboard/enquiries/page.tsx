'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '@/lib/api';
import { toast } from 'sonner';
import { CalendarDays, Plus, Save, Search, Trash2, Users } from 'lucide-react';
import FormPromptModal from '@/components/FormPromptModal';
import SortableHeader from '@/components/SortableHeader';
import {
  SortState,
  TableColumnConfig,
  filterAndSortRows,
  getNextSort,
} from '@/lib/tableUtils';

interface Enquiry {
  id: string;
  functionName: string;
  functionType: string;
  functionDate: string;
  expectedGuests: number;
  status: string;
  quotationSent?: boolean;
  isPencilBooked?: boolean;
  customer: {
    id: string;
    name: string;
    phone: string;
  };
  halls?: Array<{ id: string }>;
  packs?: Array<{ id: string }>;
}

interface CustomerOption {
  id: string;
  name: string;
  phone: string;
}

interface EnquiryFormData {
  customerId: string;
  functionName: string;
  functionType: string;
  functionDate: string;
  functionTime: string;
  expectedGuests: string;
  quotation: boolean;
  pencilBooking: boolean;
}

const initialFormData: EnquiryFormData = {
  customerId: '',
  functionName: '',
  functionType: '',
  functionDate: '',
  functionTime: '',
  expectedGuests: '100',
  quotation: false,
  pencilBooking: false,
};

const initialColumnSearch = {
  functionName: '',
  customer: '',
  functionDate: '',
  expectedGuests: '',
  status: '',
};

export default function EnquiriesPage() {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showCreatePrompt, setShowCreatePrompt] = useState(false);
  const [globalSearch, setGlobalSearch] = useState('');
  const [columnSearch, setColumnSearch] = useState(initialColumnSearch);
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState<SortState>({
    key: 'functionName',
    direction: 'asc',
  });
  const [formData, setFormData] = useState<EnquiryFormData>(initialFormData);

  const tableColumns = useMemo<TableColumnConfig<Enquiry>[]>(
    () => [
      {
        key: 'functionName',
        accessor: (enquiry) => `${enquiry.functionName} ${enquiry.functionType}`,
      },
      {
        key: 'customer',
        accessor: (enquiry) =>
          `${enquiry.customer?.name ?? ''} ${enquiry.customer?.phone ?? ''}`,
      },
      {
        key: 'functionDate',
        accessor: (enquiry) => enquiry.functionDate,
      },
      {
        key: 'expectedGuests',
        accessor: (enquiry) => enquiry.expectedGuests,
      },
      {
        key: 'status',
        accessor: (enquiry) =>
          `${enquiry.status} ${enquiry.quotationSent ? 'Quotation' : ''} ${
            enquiry.isPencilBooked ? 'Pencil' : ''
          }`,
      },
    ],
    []
  );

  const filteredEnquiries = useMemo(
    () => filterAndSortRows(enquiries, tableColumns, globalSearch, columnSearch, sort),
    [enquiries, tableColumns, globalSearch, columnSearch, sort]
  );

  useEffect(() => {
    void loadCustomers();
  }, []);

  useEffect(() => {
    void loadEnquiries();
  }, [status]);

  const loadCustomers = async () => {
    try {
      const response = await api.getCustomers({ page: 1, limit: 5000 });
      const rows = response.data?.data?.customers || [];
      setCustomers(rows);
      if (rows.length > 0) {
        setFormData((prev) => ({ ...prev, customerId: prev.customerId || rows[0].id }));
      }
    } catch (error) {
      toast.error('Failed to load customers');
    }
  };

  const loadEnquiries = async () => {
    try {
      setLoading(true);
      const response = await api.getEnquiries({
        page: 1,
        limit: 5000,
        status: status || undefined,
      });
      setEnquiries(response.data?.data?.enquiries || []);
    } catch (error) {
      toast.error('Failed to load enquiries');
    } finally {
      setLoading(false);
    }
  };

  const handleColumnSearch = (key: keyof typeof initialColumnSearch, value: string) => {
    setColumnSearch((prev) => ({ ...prev, [key]: value }));
  };

  const handleCreate = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!formData.customerId || !formData.functionName || !formData.functionType || !formData.functionDate) {
      toast.error('Customer, function name, type and date are required');
      return;
    }

    try {
      setSaving(true);
      await api.createEnquiry({
        customerId: formData.customerId,
        functionName: formData.functionName.trim(),
        functionType: formData.functionType.trim(),
        functionDate: formData.functionDate,
        functionTime: formData.functionTime || undefined,
        expectedGuests: Number(formData.expectedGuests) || 1,
        quotation: formData.quotation,
        pencilBooking: formData.pencilBooking,
      });
      toast.success('Enquiry created');
      setShowCreatePrompt(false);
      setFormData((prev) => ({
        ...initialFormData,
        customerId: prev.customerId,
      }));
      await loadEnquiries();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to create enquiry');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this enquiry?')) return;
    try {
      await api.deleteEnquiry(id);
      toast.success('Enquiry deleted');
      await loadEnquiries();
    } catch (error: any) {
      toast.error(error?.response?.data?.error || 'Failed to delete enquiry');
    }
  };

  return (
    <div className="space-y-6">
      <div className="page-head gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Enquiries</h1>
          <p className="text-gray-600 mt-1">
            Capture leads, track conversion and monitor pending follow-ups.
          </p>
        </div>
        <button
          type="button"
          className="btn btn-primary inline-flex items-center gap-2 w-full sm:w-auto justify-center"
          onClick={() => setShowCreatePrompt(true)}
          disabled={customers.length === 0}
        >
          <Plus className="w-4 h-4" />
          Add Enquiry
        </button>
      </div>

      <FormPromptModal
        open={showCreatePrompt}
        title="Create Enquiry"
        onClose={() => setShowCreatePrompt(false)}
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="label">Customer</label>
              <select
                className="input"
                value={formData.customerId}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, customerId: e.target.value }))
                }
                required
              >
                {customers.map((customer) => (
                  <option key={customer.id} value={customer.id}>
                    {customer.name} ({customer.phone})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Function name</label>
              <input
                className="input"
                value={formData.functionName}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionName: e.target.value }))
                }
                placeholder="Wedding, Reception, Birthday..."
                required
              />
            </div>
            <div>
              <label className="label">Function type</label>
              <input
                className="input"
                value={formData.functionType}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionType: e.target.value }))
                }
                placeholder="Social / Corporate"
                required
              />
            </div>
            <div>
              <label className="label">Function date</label>
              <input
                type="date"
                className="input"
                value={formData.functionDate}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionDate: e.target.value }))
                }
                required
              />
            </div>
            <div>
              <label className="label">Time</label>
              <input
                className="input"
                value={formData.functionTime}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, functionTime: e.target.value }))
                }
                placeholder="19:00"
              />
            </div>
            <div>
              <label className="label">Expected guests</label>
              <input
                className="input"
                type="number"
                min={1}
                value={formData.expectedGuests}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, expectedGuests: e.target.value }))
                }
                required
              />
            </div>
            <label className="flex items-center gap-2 text-sm text-gray-700 mt-8">
              <input
                type="checkbox"
                checked={formData.quotation}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, quotation: e.target.checked }))
                }
              />
              Quotation requested
            </label>
            <label className="flex items-center gap-2 text-sm text-gray-700 mt-8">
              <input
                type="checkbox"
                checked={formData.pencilBooking}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, pencilBooking: e.target.checked }))
                }
              />
              Pencil booking
            </label>
          </div>
          <div className="form-actions">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => setShowCreatePrompt(false)}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              <span className="inline-flex items-center gap-2">
                <Save className="w-4 h-4" />
                {saving ? 'Saving...' : 'Create Enquiry'}
              </span>
            </button>
          </div>
        </form>
      </FormPromptModal>

      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="relative md:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              className="input pl-10"
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder="Overall search across all enquiry columns..."
            />
          </div>
          <select
            className="input"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">All statuses</option>
            <option value="pending">Pending</option>
            <option value="quoted">Quoted</option>
            <option value="converted">Converted</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : filteredEnquiries.length === 0 ? (
          <div className="text-center py-12 text-gray-500">No enquiries found.</div>
        ) : (
          <div className="table-shell">
            <table className="data-table">
              <thead>
                <tr className="border-b border-gray-200">
                  <SortableHeader
                    label="Function"
                    sortKey="functionName"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Customer"
                    sortKey="customer"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Date"
                    sortKey="functionDate"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Guests"
                    sortKey="expectedGuests"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <SortableHeader
                    label="Status"
                    sortKey="status"
                    sort={sort}
                    onSort={(key) => setSort((prev) => getNextSort(prev, key))}
                  />
                  <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">
                    Actions
                  </th>
                </tr>
                <tr className="table-search-row border-b border-gray-100 bg-gray-50/70">
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search function"
                      value={columnSearch.functionName}
                      onChange={(e) => handleColumnSearch('functionName', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search customer"
                      value={columnSearch.customer}
                      onChange={(e) => handleColumnSearch('customer', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search date"
                      value={columnSearch.functionDate}
                      onChange={(e) => handleColumnSearch('functionDate', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search guests"
                      value={columnSearch.expectedGuests}
                      onChange={(e) => handleColumnSearch('expectedGuests', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4">
                    <input
                      className="input h-9"
                      placeholder="Search status"
                      value={columnSearch.status}
                      onChange={(e) => handleColumnSearch('status', e.target.value)}
                    />
                  </th>
                  <th className="py-2 px-4" />
                </tr>
              </thead>
              <tbody>
                {filteredEnquiries.map((enquiry) => (
                  <tr key={enquiry.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-4">
                      <p className="font-medium text-gray-900">{enquiry.functionName}</p>
                      <p className="text-xs text-gray-500 mt-1">{enquiry.functionType}</p>
                    </td>
                    <td className="py-4 px-4">
                      <p className="text-sm text-gray-900">{enquiry.customer?.name}</p>
                      <p className="text-xs text-gray-500 mt-1">{enquiry.customer?.phone}</p>
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-700">
                      <span className="inline-flex items-center gap-1">
                        <CalendarDays className="w-4 h-4 text-gray-400" />
                        {new Date(enquiry.functionDate).toLocaleDateString()}
                      </span>
                    </td>
                    <td className="py-4 px-4 text-sm text-gray-700">
                      <span className="inline-flex items-center gap-1">
                        <Users className="w-4 h-4 text-gray-400" />
                        {enquiry.expectedGuests}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex flex-wrap gap-2">
                        <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-700">
                          {enquiry.status}
                        </span>
                        {enquiry.quotationSent && (
                          <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-700">
                            Quotation
                          </span>
                        )}
                        {enquiry.isPencilBooked && (
                          <span className="px-2 py-1 rounded-full text-xs bg-amber-100 text-amber-700">
                            Pencil
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <button
                        onClick={() => handleDelete(enquiry.id)}
                        className="p-2 text-gray-500 hover:text-red-700 hover:bg-red-50 rounded-lg"
                        title="Delete enquiry"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
