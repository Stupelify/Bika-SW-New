'use client';

import { useEffect, useState } from 'react';
import { api } from '@/lib/api';
import {
  Users,
  CalendarCheck,
  DollarSign,
  TrendingUp,
  Calendar,
} from 'lucide-react';

interface Stats {
  totalCustomers: number;
  totalBookings: number;
  upcomingEvents: number;
  monthlyRevenue: number;
  recentBookings: any[];
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Fetch data in parallel
      const [customersRes, bookingsRes] = await Promise.all([
        api.getCustomers({ limit: 1 }),
        api.getBookings({ limit: 5 }),
      ]);

      setStats({
        totalCustomers: customersRes.data.data.pagination.total,
        totalBookings: bookingsRes.data.data.pagination.total,
        upcomingEvents: bookingsRes.data.data.bookings.filter(
          (b: any) => new Date(b.functionDate) > new Date()
        ).length,
        monthlyRevenue: 0, // Calculate from payments
        recentBookings: bookingsRes.data.data.bookings,
      });
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  const statCards = [
    {
      name: 'Total Customers',
      value: stats?.totalCustomers || 0,
      icon: Users,
      color: 'bg-blue-500',
      change: '+12%',
    },
    {
      name: 'Total Bookings',
      value: stats?.totalBookings || 0,
      icon: CalendarCheck,
      color: 'bg-green-500',
      change: '+8%',
    },
    {
      name: 'Upcoming Events',
      value: stats?.upcomingEvents || 0,
      icon: Calendar,
      color: 'bg-purple-500',
      change: '',
    },
    {
      name: 'Monthly Revenue',
      value: `₹${(stats?.monthlyRevenue || 0).toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-amber-500',
      change: '+15%',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
        <p className="text-gray-600 mt-1">
          Welcome back! Here's what's happening with your business today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => (
          <div key={stat.name} className="card">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.name}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                {stat.change && (
                  <p className="text-sm text-green-600 mt-2 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    {stat.change}
                  </p>
                )}
              </div>
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Bookings */}
      <div className="card">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Recent Bookings
        </h2>
        <div className="space-y-4">
          {stats?.recentBookings.map((booking) => (
            <div
              key={booking.id}
              className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0"
            >
              <div>
                <p className="font-medium text-gray-900">
                  {booking.functionName}
                </p>
                <p className="text-sm text-gray-600">
                  {booking.customer.name} • {booking.customer.phone}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">
                  {new Date(booking.functionDate).toLocaleDateString()}
                </p>
                <p className="text-sm text-gray-600">
                  ₹{booking.grandTotal.toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
