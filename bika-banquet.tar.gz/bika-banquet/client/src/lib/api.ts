import axios, { AxiosInstance, AxiosError } from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError<any>) => {
    if (error.response?.status === 401) {
      // Unauthorized - clear token and redirect to login
      localStorage.removeItem('auth_token');
      if (typeof window !== 'undefined') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

// API methods
export const api = {
  // Auth
  login: (email: string, password: string) =>
    apiClient.post('/auth/login', { email, password }),
  
  register: (data: any) => apiClient.post('/auth/register', data),
  
  getCurrentUser: () => apiClient.get('/auth/me'),
  
  logout: () => apiClient.post('/auth/logout'),

  // Customers
  getCustomers: (params?: any) => apiClient.get('/customers', { params }),
  
  getCustomer: (id: string) => apiClient.get(`/customers/${id}`),
  
  createCustomer: (data: any) => apiClient.post('/customers', data),
  
  updateCustomer: (id: string, data: any) =>
    apiClient.put(`/customers/${id}`, data),
  
  deleteCustomer: (id: string) => apiClient.delete(`/customers/${id}`),

  // Bookings
  getBookings: (params?: any) => apiClient.get('/bookings', { params }),
  
  getBooking: (id: string) => apiClient.get(`/bookings/${id}`),
  
  createBooking: (data: any) => apiClient.post('/bookings', data),
  
  updateBooking: (id: string, data: any) =>
    apiClient.put(`/bookings/${id}`, data),
  
  cancelBooking: (id: string) =>
    apiClient.post(`/bookings/${id}/cancel`),
  
  addPayment: (id: string, data: any) =>
    apiClient.post(`/bookings/${id}/payments`, data),
};

export default apiClient;
