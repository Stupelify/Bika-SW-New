import { Router } from 'express';
import authRoutes from './auth.routes';
import customerRoutes from './customer.routes';
import bookingRoutes from './booking.routes';

const router = Router();

// API routes
router.use('/auth', authRoutes);
router.use('/customers', customerRoutes);
router.use('/bookings', bookingRoutes);

// Health check
router.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

export default router;
