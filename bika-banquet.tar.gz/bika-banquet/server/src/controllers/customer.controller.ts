import { Request, Response } from 'express';
import { z } from 'zod';
import prisma from '../config/database';
import { sendSuccess, sendError, sendNotFound } from '../utils/response';
import { generateOTP } from '../utils/auth';

// Validation schemas
export const createCustomerSchema = z.object({
  body: z.object({
    name: z.string().min(2, 'Name must be at least 2 characters'),
    phone: z.string().min(10, 'Phone must be at least 10 digits'),
    email: z.string().email('Invalid email').optional(),
    alternatePhone: z.string().optional(),
    address: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    pincode: z.string().optional(),
    dateOfBirth: z.string().optional(),
    anniversary: z.string().optional(),
    occupation: z.string().optional(),
    companyName: z.string().optional(),
    gstNumber: z.string().optional(),
    panNumber: z.string().optional(),
    aadharNumber: z.string().optional(),
    whatsappNumber: z.string().optional(),
    instagramHandle: z.string().optional(),
    facebookProfile: z.string().optional(),
    referredById: z.string().uuid().optional(),
    notes: z.string().optional(),
  }),
});

export const updateCustomerSchema = z.object({
  body: z.object({
    name: z.string().min(2).optional(),
    phone: z.string().min(10).optional(),
    email: z.string().email().optional(),
    alternatePhone: z.string().optional(),
    address: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
    pincode: z.string().optional(),
    dateOfBirth: z.string().optional(),
    anniversary: z.string().optional(),
    occupation: z.string().optional(),
    companyName: z.string().optional(),
    gstNumber: z.string().optional(),
    panNumber: z.string().optional(),
    aadharNumber: z.string().optional(),
    whatsappNumber: z.string().optional(),
    instagramHandle: z.string().optional(),
    facebookProfile: z.string().optional(),
    referredById: z.string().uuid().optional(),
    notes: z.string().optional(),
  }),
});

/**
 * Create new customer
 */
export async function createCustomer(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const data = req.body;

    // Convert date strings to Date objects
    if (data.dateOfBirth) {
      data.dateOfBirth = new Date(data.dateOfBirth);
    }
    if (data.anniversary) {
      data.anniversary = new Date(data.anniversary);
    }

    const customer = await prisma.customer.create({
      data,
      include: {
        referredBy: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
      },
    });

    sendSuccess(res, { customer }, 'Customer created successfully', 201);
  } catch (error: any) {
    if (error.code === 'P2002') {
      sendError(res, 'Customer with this phone or email already exists', 409);
    } else {
      sendError(res, 'Failed to create customer');
    }
  }
}

/**
 * Get all customers with pagination and search
 */
export async function getCustomers(req: Request, res: Response): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const search = req.query.search as string;

    const skip = (page - 1) * limit;

    // Build where clause for search
    const where: any = {};
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
        { email: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [customers, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          referredBy: {
            select: {
              id: true,
              name: true,
              phone: true,
            },
          },
          _count: {
            select: {
              enquiries: true,
              bookings: true,
              referrals: true,
            },
          },
        },
      }),
      prisma.customer.count({ where }),
    ]);

    sendSuccess(res, {
      customers,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    sendError(res, 'Failed to fetch customers');
  }
}

/**
 * Get customer by ID
 */
export async function getCustomerById(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;

    const customer = await prisma.customer.findUnique({
      where: { id },
      include: {
        referredBy: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
        referrals: {
          select: {
            id: true,
            name: true,
            phone: true,
            createdAt: true,
          },
        },
        enquiries: {
          orderBy: { createdAt: 'desc' },
          take: 10,
        },
        bookings: {
          orderBy: { functionDate: 'desc' },
          take: 10,
          where: { isLatest: true },
        },
      },
    });

    if (!customer) {
      sendNotFound(res, 'Customer not found');
      return;
    }

    sendSuccess(res, { customer });
  } catch (error) {
    sendError(res, 'Failed to fetch customer');
  }
}

/**
 * Update customer
 */
export async function updateCustomer(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;
    const data = req.body;

    // Convert date strings
    if (data.dateOfBirth) {
      data.dateOfBirth = new Date(data.dateOfBirth);
    }
    if (data.anniversary) {
      data.anniversary = new Date(data.anniversary);
    }

    const customer = await prisma.customer.update({
      where: { id },
      data,
      include: {
        referredBy: {
          select: {
            id: true,
            name: true,
            phone: true,
          },
        },
      },
    });

    sendSuccess(res, { customer }, 'Customer updated successfully');
  } catch (error: any) {
    if (error.code === 'P2025') {
      sendNotFound(res, 'Customer not found');
    } else if (error.code === 'P2002') {
      sendError(res, 'Customer with this phone or email already exists', 409);
    } else {
      sendError(res, 'Failed to update customer');
    }
  }
}

/**
 * Delete customer
 */
export async function deleteCustomer(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;

    await prisma.customer.delete({
      where: { id },
    });

    sendSuccess(res, null, 'Customer deleted successfully');
  } catch (error: any) {
    if (error.code === 'P2025') {
      sendNotFound(res, 'Customer not found');
    } else {
      sendError(res, 'Failed to delete customer');
    }
  }
}

/**
 * Send OTP to customer
 */
export async function sendOTP(req: Request, res: Response): Promise<void> {
  try {
    const { phone } = req.body;

    const otp = generateOTP();
    const otpExpiry = new Date();
    otpExpiry.setMinutes(otpExpiry.getMinutes() + 10); // 10 minutes

    // Update or create customer with OTP
    await prisma.customer.upsert({
      where: { phone },
      update: {
        otpCode: otp,
        otpExpiry,
      },
      create: {
        phone,
        name: 'Guest', // Temporary name
        otpCode: otp,
        otpExpiry,
      },
    });

    // TODO: Send SMS with OTP

    sendSuccess(res, null, 'OTP sent successfully');
  } catch (error) {
    sendError(res, 'Failed to send OTP');
  }
}

/**
 * Verify OTP
 */
export async function verifyOTP(req: Request, res: Response): Promise<void> {
  try {
    const { phone, otp } = req.body;

    const customer = await prisma.customer.findUnique({
      where: { phone },
    });

    if (!customer || !customer.otpCode || !customer.otpExpiry) {
      sendError(res, 'Invalid or expired OTP', 400);
      return;
    }

    if (customer.otpExpiry < new Date()) {
      sendError(res, 'OTP has expired', 400);
      return;
    }

    if (customer.otpCode !== otp) {
      sendError(res, 'Invalid OTP', 400);
      return;
    }

    // Mark as verified and clear OTP
    const updatedCustomer = await prisma.customer.update({
      where: { phone },
      data: {
        isVerified: true,
        otpCode: null,
        otpExpiry: null,
      },
    });

    sendSuccess(res, { customer: updatedCustomer }, 'OTP verified successfully');
  } catch (error) {
    sendError(res, 'Failed to verify OTP');
  }
}
