import { Request, Response } from 'express';
import { z } from 'zod';
import prisma from '../config/database';
import { sendSuccess, sendError, sendNotFound } from '../utils/response';
import { AuthRequest } from '../middleware/auth.middleware';

// Validation schemas
export const createBookingSchema = z.object({
  body: z.object({
    customerId: z.string().uuid('Invalid customer ID'),
    secondCustomerId: z.string().uuid().optional(),
    referredById: z.string().uuid().optional(),
    functionName: z.string().min(2, 'Function name is required'),
    functionType: z.string().min(2, 'Function type is required'),
    functionDate: z.string(),
    functionTime: z.string(),
    expectedGuests: z.number().min(1, 'Expected guests must be at least 1'),
    confirmedGuests: z.number().optional(),
    isQuotation: z.boolean().optional(),
    halls: z.array(z.object({
      hallId: z.string().uuid(),
      charges: z.number().min(0),
    })).optional(),
    packs: z.array(z.object({
      mealSlotId: z.string().uuid(),
      packName: z.string(),
      packCount: z.number().min(1),
      ratePerPlate: z.number().min(0),
      setupCost: z.number().min(0).optional(),
      extraCharges: z.number().min(0).optional(),
      hallName: z.string().optional(),
      timeSlot: z.string().optional(),
      tags: z.array(z.string()).optional(),
      menu: z.object({
        name: z.string(),
        items: z.array(z.object({
          itemId: z.string().uuid(),
          quantity: z.number().min(1),
        })),
      }),
    })).optional(),
    additionalItems: z.array(z.object({
      description: z.string(),
      charges: z.number(),
      quantity: z.number().min(1).optional(),
    })).optional(),
    discountAmount: z.number().min(0).optional(),
    discountPercentage: z.number().min(0).max(100).optional(),
    notes: z.string().optional(),
    internalNotes: z.string().optional(),
  }),
});

/**
 * Create new booking
 */
export async function createBooking(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const data = req.body;

    // Start transaction
    const booking = await prisma.$transaction(async (tx) => {
      // Create booking
      const newBooking = await tx.booking.create({
        data: {
          customerId: data.customerId,
          secondCustomerId: data.secondCustomerId,
          referredById: data.referredById,
          functionName: data.functionName,
          functionType: data.functionType,
          functionDate: new Date(data.functionDate),
          functionTime: data.functionTime,
          expectedGuests: data.expectedGuests,
          confirmedGuests: data.confirmedGuests,
          isQuotation: data.isQuotation || false,
          notes: data.notes,
          internalNotes: data.internalNotes,
        },
      });

      // Create hall associations
      if (data.halls && data.halls.length > 0) {
        await tx.bookingHall.createMany({
          data: data.halls.map((hall: any) => ({
            bookingId: newBooking.id,
            hallId: hall.hallId,
            charges: hall.charges,
          })),
        });
      }

      // Create packs with menus
      if (data.packs && data.packs.length > 0) {
        for (const pack of data.packs) {
          // Create menu
          const menu = await tx.bookingMenu.create({
            data: {
              name: pack.menu.name,
              setupCost: pack.setupCost || 0,
              ratePerPlate: pack.ratePerPlate,
              mealSlotId: pack.mealSlotId,
            },
          });

          // Add menu items
          if (pack.menu.items && pack.menu.items.length > 0) {
            await tx.bookingMenuItems.createMany({
              data: pack.menu.items.map((item: any) => ({
                bookingMenuId: menu.id,
                itemId: item.itemId,
                quantity: item.quantity,
              })),
            });
          }

          // Create pack
          await tx.bookingPack.create({
            data: {
              bookingId: newBooking.id,
              mealSlotId: pack.mealSlotId,
              bookingMenuId: menu.id,
              packName: pack.packName,
              packCount: pack.packCount,
              ratePerPlate: pack.ratePerPlate,
              setupCost: pack.setupCost || 0,
              extraCharges: pack.extraCharges || 0,
              hallName: pack.hallName,
              timeSlot: pack.timeSlot,
              tags: pack.tags || [],
            },
          });
        }
      }

      // Create additional items
      if (data.additionalItems && data.additionalItems.length > 0) {
        await tx.additionalBookingItems.createMany({
          data: data.additionalItems.map((item: any) => ({
            bookingId: newBooking.id,
            description: item.description,
            charges: item.charges,
            quantity: item.quantity || 1,
          })),
        });
      }

      // Calculate totals
      let totalAmount = 0;

      // Add hall charges
      if (data.halls) {
        totalAmount += data.halls.reduce((sum: number, h: any) => sum + h.charges, 0);
      }

      // Add pack charges
      if (data.packs) {
        for (const pack of data.packs) {
          const packTotal =
            (pack.ratePerPlate * pack.packCount) +
            (pack.setupCost || 0) +
            (pack.extraCharges || 0);
          totalAmount += packTotal;
        }
      }

      // Add additional items
      if (data.additionalItems) {
        totalAmount += data.additionalItems.reduce(
          (sum: number, item: any) => sum + item.charges * (item.quantity || 1),
          0
        );
      }

      // Calculate discount
      let discountAmount = data.discountAmount || 0;
      if (data.discountPercentage && data.discountPercentage > 0) {
        discountAmount = (totalAmount * data.discountPercentage) / 100;
      }

      const grandTotal = totalAmount - discountAmount;
      const balanceAmount = grandTotal - (data.advanceReceived || 0);

      // Update booking with totals
      return await tx.booking.update({
        where: { id: newBooking.id },
        data: {
          totalAmount,
          discountAmount,
          discountPercentage: data.discountPercentage || 0,
          grandTotal,
          balanceAmount,
        },
        include: {
          customer: true,
          secondCustomer: true,
          halls: {
            include: {
              hall: true,
            },
          },
          packs: {
            include: {
              mealSlot: true,
              bookingMenu: {
                include: {
                  items: {
                    include: {
                      item: true,
                    },
                  },
                },
              },
            },
          },
          additionalItems: true,
        },
      });
    });

    sendSuccess(res, { booking }, 'Booking created successfully', 201);
  } catch (error: any) {
    console.error('Booking creation error:', error);
    sendError(res, 'Failed to create booking');
  }
}

/**
 * Get all bookings with filters
 */
export async function getBookings(req: Request, res: Response): Promise<void> {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const status = req.query.status as string;
    const search = req.query.search as string;
    const fromDate = req.query.fromDate as string;
    const toDate = req.query.toDate as string;
    const isQuotation = req.query.isQuotation === 'true';

    const skip = (page - 1) * limit;

    // Build where clause
    const where: any = { isLatest: true };

    if (status) {
      where.status = status;
    }

    if (isQuotation !== undefined) {
      where.isQuotation = isQuotation;
    }

    if (search) {
      where.OR = [
        { functionName: { contains: search, mode: 'insensitive' } },
        { functionType: { contains: search, mode: 'insensitive' } },
        { customer: { name: { contains: search, mode: 'insensitive' } } },
        { customer: { phone: { contains: search } } },
      ];
    }

    if (fromDate || toDate) {
      where.functionDate = {};
      if (fromDate) {
        where.functionDate.gte = new Date(fromDate);
      }
      if (toDate) {
        where.functionDate.lte = new Date(toDate);
      }
    }

    const [bookings, total] = await Promise.all([
      prisma.booking.findMany({
        where,
        skip,
        take: limit,
        orderBy: { functionDate: 'desc' },
        include: {
          customer: {
            select: {
              id: true,
              name: true,
              phone: true,
              email: true,
            },
          },
          halls: {
            include: {
              hall: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
          _count: {
            select: {
              payments: true,
            },
          },
        },
      }),
      prisma.booking.count({ where }),
    ]);

    sendSuccess(res, {
      bookings,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    sendError(res, 'Failed to fetch bookings');
  }
}

/**
 * Get booking by ID
 */
export async function getBookingById(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;

    const booking = await prisma.booking.findUnique({
      where: { id },
      include: {
        customer: true,
        secondCustomer: true,
        halls: {
          include: {
            hall: true,
          },
        },
        packs: {
          include: {
            mealSlot: true,
            bookingMenu: {
              include: {
                items: {
                  include: {
                    item: {
                      include: {
                        itemType: true,
                      },
                    },
                  },
                },
              },
            },
          },
        },
        additionalItems: true,
        payments: {
          include: {
            receiver: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
        previousBooking: true,
        nextVersion: true,
      },
    });

    if (!booking) {
      sendNotFound(res, 'Booking not found');
      return;
    }

    sendSuccess(res, { booking });
  } catch (error) {
    sendError(res, 'Failed to fetch booking');
  }
}

/**
 * Update booking
 */
export async function updateBooking(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;
    const data = req.body;

    // Check if booking exists
    const existingBooking = await prisma.booking.findUnique({
      where: { id },
    });

    if (!existingBooking) {
      sendNotFound(res, 'Booking not found');
      return;
    }

    // Create new version if not a quotation
    if (!existingBooking.isQuotation && data.createNewVersion) {
      // Mark current as not latest
      await prisma.booking.update({
        where: { id },
        data: { isLatest: false },
      });

      // Create new version
      const newVersion = await prisma.booking.create({
        data: {
          ...existingBooking,
          id: undefined, // Let Prisma generate new ID
          previousBookingId: id,
          versionNumber: existingBooking.versionNumber + 1,
          isLatest: true,
          updatedAt: new Date(),
        } as any,
      });

      sendSuccess(res, { booking: newVersion }, 'New booking version created');
      return;
    }

    // Update existing booking
    const booking = await prisma.booking.update({
      where: { id },
      data: {
        ...data,
        functionDate: data.functionDate
          ? new Date(data.functionDate)
          : undefined,
      },
      include: {
        customer: true,
        halls: {
          include: {
            hall: true,
          },
        },
        packs: {
          include: {
            mealSlot: true,
            bookingMenu: true,
          },
        },
      },
    });

    sendSuccess(res, { booking }, 'Booking updated successfully');
  } catch (error) {
    sendError(res, 'Failed to update booking');
  }
}

/**
 * Cancel booking
 */
export async function cancelBooking(
  req: Request,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;

    const booking = await prisma.booking.update({
      where: { id },
      data: {
        status: 'cancelled',
      },
    });

    sendSuccess(res, { booking }, 'Booking cancelled successfully');
  } catch (error: any) {
    if (error.code === 'P2025') {
      sendNotFound(res, 'Booking not found');
    } else {
      sendError(res, 'Failed to cancel booking');
    }
  }
}

/**
 * Add payment to booking
 */
export async function addPayment(
  req: AuthRequest,
  res: Response
): Promise<void> {
  try {
    const { id } = req.params;
    const { amount, method, reference, narration, paymentDate } = req.body;

    if (!req.user) {
      sendError(res, 'Unauthorized', 401);
      return;
    }

    const payment = await prisma.$transaction(async (tx) => {
      // Create payment
      const newPayment = await tx.bookingPayments.create({
        data: {
          bookingId: id,
          receivedBy: req.user!.userId,
          amount,
          method,
          reference,
          narration,
          paymentDate: paymentDate ? new Date(paymentDate) : new Date(),
        },
      });

      // Update booking balance
      const booking = await tx.booking.findUnique({
        where: { id },
      });

      if (booking) {
        await tx.booking.update({
          where: { id },
          data: {
            advanceReceived: booking.advanceReceived + amount,
            balanceAmount: booking.balanceAmount - amount,
          },
        });
      }

      return newPayment;
    });

    sendSuccess(res, { payment }, 'Payment added successfully', 201);
  } catch (error) {
    sendError(res, 'Failed to add payment');
  }
}
